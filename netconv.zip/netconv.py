#! /usr/bin/python3
# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 Chris Rogers 31st March 2020, 2026

import tkinter as tk
from tkinter import filedialog, messagebox
from pathlib import Path
import shlex, os, sys
import xml.etree.ElementTree as ET

version = 'v0.2.0'

partlist    = []                # array of parts with input/output names
components  = []                # list of parts ready for output
networks    = []                # list of networks ready for output

warning     = ''                # rows of warning text
namehelp    = 'netconv.hlp'     # help file
filepartsQD = 'partsQ.dat'      # parts file Qucs-s -> DIYLC 
filepartsKD = 'partsK.dat'      # parts file KiCAD  -> DIYLC

extSim = '.sim'                 # ext for qucs simulation file
extXml = '.xml'                 # ext for kicad xml file
extNet = '.net'                 # output netlist file

inputType = ''                  # whether from qucs or kicad

# COMMON BITS===================================================================
#-------------------------------------------------------------------------------
def resourcePath(name: str) -> Path:
  import sys
  if hasattr(sys, '_MEIPASS'):
    base = Path(sys._MEIPASS)
  else:
    base = Path(__file__).resolve().parent
  return base / name

#-------------------------------------------------------------------------------
def read_text(path: Path) -> str:
  try:
    return path.read_text(encoding='utf-8')
  except UnicodeDecodeError:
    return path.read_text(encoding='latin-1')
   
#-------------------------------------------------------------------------------
def showHelp(root):
  global warning
  
  text = tk.Text(root, wrap='word', height = 15)
  text.pack(expand=True, fill='both') # remove for selection buttons
  text.pack(fill = 'both') # fill = 'x' if using output selection buttons
    
  scrollbar = tk.Scrollbar(root, command=text.yview)
  scrollbar.pack(side='right', fill='y')
  text.configure(yscrollcommand=scrollbar.set)
  help_path = resourcePath(namehelp)

  if help_path.exists():
    content = read_text(help_path)
    text.insert('1.0', content)
    text.config(state='disabled')  # read-only  
  else:
    messagebox.showinfo('Info', 'Failed to read help file.')
  
#-------------------------------------------------------------------------------
def loadParts():
  # Load partlist CGPT
  # local line

  if inputType == 'q':
    partlist_path = resourcePath(filepartsQD)
  else: #'k'
    partlist_path = resourcePath(filepartsKD)

  if not partlist_path.exists():
    messagebox.showinfo('Error', 'Parts list file not found.')
    return False

  with open(partlist_path, 'r') as fpl: 
    try: 
      line = fpl.readline()
    except:
      messagebox.showinfo('Error', 'Empty parts list file.')
      return False
        
    if not ((inputType == 'q' and line[:14] == '<Qucs Partlist')
        or
       (inputType == 'k' and line[:15] == '<KiCAD Partlist')):
      messagebox.showinfo('Error', 'Invalid or empty parts list file.')
      return False
    else:
      line = ''; lineno = 0
      while line != []: 
        lineno += 1
        line = fpl.readline() 
        line = shlex.split(line)
        if line != []:
          partlist.append(line)
  return True

#-------------------------------------------------------------------------------
def chooseFile(root):
  path = filedialog.askopenfilename(
    title='Select a schematic',
    initialdir=str(Path.home()),
    filetypes=[('Schematic', '*.*')]
  )
  if path:
    return Path(path)
  else:
    root.destroy()

#-------------------------------------------------------------------------------
def fileType(): #2 Check schematic files
  global inputType
  # local fin, line, e

  e = ''
  if os.path.isfile(fileSch):
    try:
      with open(fileSch, 'r') as fin:  
        try:
          line = fin.readline()
          if line[:15] == '<Qucs Schematic':
            inputType = 'q'
            return True
          else:
            line = fin.readline(); line = fin.readline(); line = fin.readline()
            if line.find('(generator_version "9.0")') > 0:
              inputType = 'k'
              return True
            else:
              e = 2
        except:
          e = 2
    except:
      e = 2
  else:
    e = 1
  
  if e == 1:
    messagebox.showinfo('Error', 'No input file.')
  else:
    messagebox.showinfo('Error', 'Invalid input file.')
  
  return False
  
  
# command FILE CREATION =========================================================     
#-------------------------------------------------------------------------------
# check whether a valid xml file exists and if not, create one if kicad is available
def commandXML():
  global line, warning

  e = ''   
  # try to create an XML file 
  command =  ' sch export netlist --format kicadxml ' + fileSch + ' -o ' + fileXml
  try:
    result = os.system('kicad-cli' + command)
    if result != 0:
      try:
        result = os.system('flatpak run --command=kicad-cli org.kicad.kicad ' + command)
        if result != 0:
          e = 1
      except:
        e = 1
  except:
    e = 1
              
  # check whether a valid xml file exists now
  if os.path.isfile(fileXml):
    try:
      with open(fileXml, 'r') as fin:  
        try:
          line = fin.readline()
          line = fin.readline()
          if line[:20] == '<export version="E">':
            return True
          else:
            e = 2
        except:
          e = 2
    except:
      e = 2

  if e == 1:
    messagebox.showinfo('Info', 'Failed to create intermediate file.')  
  elif e == 2:
    messagebox.showinfo('Info', 'The intermediate file is invalid.')

  return False

# READ INPUT FILES =============================================================
#-------------------------------------------------------------------------------
def checkComponents(line): # Check parts and make list of valid ones in components
  global components, warning
      
  #fields count 0 onwards
  if line[2] == '1': # component is active
      
    pfield9 = '' ; pfield11 = '' ; pfield13 = ''
    if len(line) > 9:
      pfield9 = line[9]
  
      if len(line) > 11:
        pfield11 = line[11]

        if len(line) > 13:
          pfield13 = line[13]

    pqucs = line[0]; pname = line[1]; pactive = line[2]
    if pqucs == 'Lib':
      pqucs = pfield9; pdetailA = pfield11 ; pdetailB = ''
    else:
      pqucs = line[0]; pdetailA = pfield9 ; pdetailB = pfield13 
  
    pdetail = '' ; foundpart = False

    for sublist in partlist:    
      if sublist[0] == pqucs:
        if sublist[1] == ''  or (sublist[1] == '9' and sublist[2] == pdetailA):
          foundpart = True
          components.append(pname)
          return('[\n'+pname+'\n'+sublist[3]+'\n'+pdetailA+'\n\n\n]\n')

        elif (sublist[1] == '13' and sublist[2] == pdetailB):
          foundpart = True
          components.append(pname)
          # whole set of lines for one component
          return('[\n'+pname+'\n'+sublist[3]+'\n'+pdetailB+'\n\n\n]\n') 

    if not foundpart:
      warning = warning + 'Unknown component type not converted: '+pname + ' ' + pqucs + '\n'
      return(None)

#-------------------------------------------------------------------------------
# Qucs input file - read and process sch file for components and write to output file
def parseQ(): # and write to file
  global warning

  try:
    with open(fileSch, 'r') as fin:
      with open(fileNet, 'w') as fout:

        # skip lines before components start
        line = '~'; lineno = 0
        while line[:12] != '<Components>' and line != '':
          line = fin.readline();  lineno += 1
    
        # read line until components end or > 1000 lines
        while line != '': #and lineno < 1000:
          line = fin.readline(); lineno += 1
          if line[:13] == '</Components>':
            break
          line = line[3:-2] #remove '  <' and '>\n'
          line = shlex.split(line)   # put into fields on ' ' and stripping double-quotes
          lineout = checkComponents(line)
          if lineout != None:
            fout.write(lineout)
      return True      
  except:
    messagebox.showinfo('Error', 'Failed to read schematic file.')
    return False

#-------------------------------------------------------------------------------    
def transK(fp):
  for record in partlist:
    if fp == record[0]:
      fp = record[3]
      break
  return fp     
      
#-------------------------------------------------------------------------------    
def parseK():
    global components, networks, warning

    components = []
    networks = []

    try:
        tree = ET.parse(fileXml)
        root = tree.getroot()

        # Components         
        comps = root.find('components')
        if comps is not None:
          for c in comps.findall('comp'):
            ref = c.attrib.get('ref', '')
            value = c.findtext('value', default='')

            lib = c.find('libsource')
            part = ''
            if lib is not None:
              part = lib.attrib.get('part', '')
            part = transK(part)
            comp = [ref, part, value, '', '']
            components.append(comp)                      
                      
        # Nets
        nets = root.find('nets')
        if nets is not None:
            for n in nets.findall('net'):
                code = n.attrib.get('code', '0')

                try:
                    netname = '_net' + str(int(code) - 1)
                except:
                    netname = '_net0'

                net = [netname]

                for node in n.findall('node'):
                    ref = node.attrib.get('ref', '')
                    pin = node.attrib.get('pin', '')
                    net.append(f"{ref}-{pin}")

                networks.append(net)

        return True

    except Exception as e:
        warning = f"XML parse error: {e}"
        return False

# QUCS NETS ====================================================================
#-------------------------------------------------------------------------------
def appendPin(net, pin):
  global networks

  foundnet = False
  for sublist in networks:
    if sublist[0] == net:
      foundnet = True
  if not foundnet: # net not found, so add a new row for it
    networks.append([net])
  
  # look for net, find it and add pin
  for sublist in networks:
    if sublist[0] == net:
      sublist.append(pin)
      break
      
#-------------------------------------------------------------------------------
def parseSim(line):
  # inactive components don't get into sim file
  pname = line[1]; pqucs = line[0]
  fieldtotal = len(line)

  if pname in components:
    validnet = []
    for fno in range (2,fieldtotal): # skip the first 2 irrelevant fields
      # find all the pins in the line
      if '=' not in line[fno]:
        if line[fno] not in validnet: # to avoid transistors with 4 pins
          validnet.append(line[fno])
          pin = line[1]+'-'+str(fno-1) #take 1 from fno because 0 and 1 have other data
          appendPin(line[fno], pin)  # add pin connection to net

#-------------------------------------------------------------------------------
def readSim():
  # local line
  # process simfile to create nets
  
  # find last .Def:End to give number of lines to skip 
  with open(fileSim, 'r') as fin:
    line='~'; lineno = 0; skip = 0
    while line != '':
      line = fin.readline();  lineno += 1
      if '.Def:End' in line:
        skip = lineno

    #read sim file and compile list of nets
    with open(fileSim, 'r') as fin:
      # skip the .def lines
      line = '~'; lineno = 0
      while line != '' and lineno < skip:        
        line = fin.readline();  lineno += 1

      # read line until components end or > 1000 lines
      while line != '':
        line = fin.readline(); lineno += 1
        if line[0:1] != '.' and line[0:1] != ' ' and line.find(':') > -1 and line.find(' ') > line.find(':'):                     # its a component line
          line = line[:-1]                  # remove \n      
          line = line.replace(':', ' ', 1)  # remove colon marker in components
          line = shlex.split(line)          # put into fields on ' ' and strip '
          parseSim(line)

#---------------------------------------------------------------------------------
# check whether a valid sim file exists and if not, create one if qucs is available
def commandSim():
  global warning
  
  if not os.path.isfile(fileSim): 
    # no valid sim file exists so try to create one
    # -n = no terminal, -i = inputfile, -o = outputfile
    command = 'qucs-s -n -i ' + fileSch + ' -o ' + fileSim
    try:
      result = os.system(command)
    except:  
      try:
        command = 'flatpak run io.github.ra3xdh.qucs_s -n -i ' + fileSch + ' -o ' + fileSim     
        result = os.system(command)
      except:
        pass
          
  # check whether a valid sim file exists now
  if os.path.isfile(fileSim):
    try:
      with open(fileSim, 'r') as fin:  
        try:
          line = fin.readline()
          if line[:6] == '# Qucs':
            return True
          else:          
            messagebox.showinfo('Info', 'The Qucs simulation file is invalid. There will be no net data.');
            return False 
        except:
          messagebox.showinfo('Info', 'Cannot read the Qucs simulation file. There will be no net data.')
          return False
    except:
      messagebox.showinfo('Info', 'Cannot open the Qucs simulation file. There will be no net data.')
      return False
  else:
    messagebox.showinfo('Info', 'Cannot find a Qucs simulation file. There will be no net data.')  
  
# ----------------------- Output Modules -----------------------
# write DIYLC file
def writeDIYLC(fileSim):
  # local line, netno, pinno, item, name

  # only write components from kicad, as qucs ones have already been done
  if inputType == 'k':
    #components
    with open(fileNet, 'w') as fout:
      for name in components:
        fout.write('[\n')
        for item in name:
          fout.write(item+'\n')
        fout.write(']\n')

  with open(fileNet, 'a') as fout:
    for name in networks:
      fout.write('(\n')
      for item in name:
        fout.write(item+'\n')
      fout.write(')\n')
  fout.close
     
      
# ----------------------- Main GUI -----------------------
def main():
  global warning, path, fileSim, fileXml, fileNet, fileSch
   
  root = tk.Tk()
  root.title('Qucs-netlist ' + version)
  root.geometry('700x550')
  
  # show help window  
  showHelp(root)

  # input file selection
  path = chooseFile(root)
  if not path:
    return

  # filenames
  fileSch = str(path)
  #fileSch = '/home/chris/example2.kicad_sch'
  #fileSch = '/home/chris/example2.sch'
  
  directory = path.parent ; filename = path.stem #; ext =  path.suffix
  fileSim = str(directory) + '/' + str(filename) + extSim
  fileXml = str(directory) + '/' + str(filename) + extXml
  fileNet = str(directory) + '/' + str(filename) + extNet

  #2 check which file type input file is
  success = fileType()
  if not success:
    return

  # depending on which input file type it is, load appropriate partslist.
  success = loadParts()
  if not success: 
    return

  # Produce intermediate files
  if inputType == 'q': 
    oksim = commandSim() # command Qucs to output sim file
    success = True    
  else:
    success = commandXML() # command Kicad to output XML file
    oksim = False
  if not success:
    return
  
  if inputType == 'q':
    success = parseQ()      
  else: # must be a k
    success = parseK()   
  if not success:
    return

  if inputType == 'q' and oksim: # read sim file    
    readSim() # input simulation file
  if not success:
    warning = warning + 'No nets were added.'

  writeDIYLC(oksim)

  warning = 'Created ' + fileNet + '\n\n' + warning  
  messagebox.showinfo('Information', warning)
        
  #root.mainloop() ##

if __name__ == '__main__':
  main()

